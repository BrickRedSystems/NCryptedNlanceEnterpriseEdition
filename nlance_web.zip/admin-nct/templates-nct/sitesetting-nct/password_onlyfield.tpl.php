<input type="password" class="%CLASS%" name="%NAME%" id="%ID%" value="%VALUE%" %EXTRA% />
