<label>
<div class="ckecker"> <span>
  <input type="checkbox" class="%CLASS%" id="%ID%" name="%NAME%" value="%VALUE%"  %CHECKED%  %EXTRA% />
  </span> </div>
%DISPLAY_VALUE%
</label>
<span for="%NAME%" class="help-block"></span> 