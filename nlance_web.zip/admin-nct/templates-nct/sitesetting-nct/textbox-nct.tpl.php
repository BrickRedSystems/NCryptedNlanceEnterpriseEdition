<div class="form-group">
    <label for="%NAME%" class="control-label col-md-4">%LABEL%&nbsp;</label>
    <div class="col-md-8">
        <input type="text" class="%CLASS%" name="%NAME%" id="%ID%" value="%VALUE%" %EXTRA% />
    </div>
</div>
