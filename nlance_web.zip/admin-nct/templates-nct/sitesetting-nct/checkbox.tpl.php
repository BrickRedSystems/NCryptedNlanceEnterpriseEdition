<div class="form-group">
  <label class="control-label col-md-3">%LABEL%&nbsp;</label>
  <div class="col-md-4">
    <div class="checkbox-list" data-error-container="#form_2_%LABEL%_error">
    	%CHECKBOX_LIST%
    </div>
    <div id="form_2_%LABEL%_error"></div>
  </div>
</div>
