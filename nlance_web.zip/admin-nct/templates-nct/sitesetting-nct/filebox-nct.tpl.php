<div class="form-group">
  <label for="%NAME%" class="control-label col-md-4">%LABEL%&nbsp;</label>
  <div class="col-md-8">
    <input type="file" class="%CLASS%" name="%NAME%" id="%ID%" %EXTRA%  />
    %VALUE% %HELPTEXT% 
  </div>
</div>
