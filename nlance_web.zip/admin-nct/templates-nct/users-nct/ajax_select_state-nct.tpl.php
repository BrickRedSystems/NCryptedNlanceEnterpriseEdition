<select name="state" id="state" class="form-control selectBox-bg required" onchange="javascript:changeState(this.value)">
    <option value="">Select State</option>
    %STATE_OPTION%
</select>