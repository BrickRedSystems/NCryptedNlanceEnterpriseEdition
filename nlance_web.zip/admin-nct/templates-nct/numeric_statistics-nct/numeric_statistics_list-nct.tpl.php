<div class="form-body">
	<div class="table-responsive">
		<table class="table table-condensed table-hover">
	    <thead>
		    <tr>
		        <th>Title</th>
		        <th>Numerical Statistics</th>
		    </tr>
		</thead>
		<tbody>
		    <tr>
		        <td>Total no. of users</td>
		        <td>%TOTAL_USERS%</td>
		    </tr>
		    <tr>
		        <td>Total no. of providers</td>
		        <td>%TOTAL_PROVIDERS%</td>
		    </tr>
		    <tr>
		        <td>Total no. of customers</td>
		        <td>%TOTAL_CUSTOMERS%</td>
		    </tr>
		    <tr>
		        <td>Total no. of projects</td>
		        <td>%TOTAL_PROJECTS%</td>
		    </tr>
	    </tbody>
	 </table>
	</div>
</div>