<li> 
	<a href="javascript:void(0);">
    	 <i class="fa %IMAGE%"></i>
         <span class="title">%SECTION_NAME%</span>
         <span class="arrow "></span>
	</a>
    %SUBMENU_LIST%
</li>
    