

<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <a href="%PAGE_LINK%" title="%PAGE_TITLE%">
        <div class="dashboard-stat %COLOR%">
            <div class="visual">
                <i class="fa %IMAGE%"></i>
            </div>
            <div class="details">
                <div class="number" id="getcustomer">
                    %COUNT%
                </div>
                <div class="desc">
                    %PAGE_TITLE%
                </div>
            </div>

        </div>

    </a>
</div>