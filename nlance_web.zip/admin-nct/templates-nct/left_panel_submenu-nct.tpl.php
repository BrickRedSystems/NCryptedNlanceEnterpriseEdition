<ul class="sub-menu">
	%SUBMENU_ITEMS%
</ul>