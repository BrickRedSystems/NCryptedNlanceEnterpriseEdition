<li>
    <a href="%NOTIFICATION_URL%" title="%NOTIFICATION_TITLE%">
        %NOTIFICATION%
        <span class="time">
            %NOTIFICATION_DATE% - %TIME_AGO%
        </span>
    </a>
</li>