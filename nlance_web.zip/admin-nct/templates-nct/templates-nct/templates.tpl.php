<div class="form-group">
	<label class="control-label col-md-3"> %MEND_SIGN%
	Template (%languageName%): &nbsp;
	</label>
	<div class="col-md-9">
		<textarea class="ckeditor form-control textarea-bg required" name="templates[%id%]" id="templates[%id%]">
			%TEMPLATES%
		</textarea>
	</div>
</div>
<script type="text/javascript">$(function(){loadCKE("templates[%id%]");});</script>
<div class="flclear clearfix"></div>