<div class="form-group">
    <label class="control-label col-md-3" for="subject">
        %MEND_SIGN%
		Subject (%languageName%):
    </label>
    <div class="col-md-4">
        <input class="form-control logintextbox-bg required" id="subject[%id%]" name="subject[%id%]" type="text" value="%SUBJECT%"/>
    </div>
</div>
<div class="padtop10 flclear">
</div>