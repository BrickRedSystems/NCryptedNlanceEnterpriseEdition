<div class="form-group">
  <label for="%NAME%" class="control-label col-md-3">%LABEL%&nbsp;</label>
  <div class="col-md-4">
    <input type="text" class="%CLASS%" name="%NAME%" id="%ID%" value="%VALUE%" %EXTRA% />
  </div>
</div>
