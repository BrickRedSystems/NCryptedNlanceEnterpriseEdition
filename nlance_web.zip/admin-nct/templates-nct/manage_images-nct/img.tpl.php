<!--<span>
	<a href="%HREF%" class="thickbox">
    	<img src="%SRC%" class="%CLASS%" id="%ID%" alt="%ALT%" width="%WIDTH%" height="%HEIGHT%" %EXTRA% >
    </a>
</span>-->

<div class="form-group">
  <label for="%NAME%" class="control-label col-md-3">%LABEL%&nbsp;</label>
  <div class="col-md-4">
  	<a href="%HREF%" class="thickbox">
    	<img src="%SRC%" class="%CLASS%" id="%ID%" alt="%ALT%" width="%WIDTH%" height="%HEIGHT%" %EXTRA% >
     </a>   
  </div>
</div>
