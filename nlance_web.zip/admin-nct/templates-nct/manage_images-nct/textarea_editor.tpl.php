<div class="padtop10 flclear"></div>
<div class="form-group">
  <label class="control-label col-md-3">%LABEL%&nbsp;</label>
  <div class="col-md-9">
    <textarea class="%CLASS%" name="%NAME%" id="%ID%" %EXTRA% data-error-container="#editor_error" >%VALUE%</textarea>
    <div id="editor_error"></div>
  </div>
</div>
<script type="text/javascript">
	$(function(){loadCKE("%NAME%");});
</script>
