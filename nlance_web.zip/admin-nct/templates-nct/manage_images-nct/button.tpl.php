<div class="flclear clearfix"></div>
<span>%BUTTON%</span>