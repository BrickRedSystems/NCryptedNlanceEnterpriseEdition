 <form action="%ACTION%" method="%METHOD%" name="%NAME%" id="%ID%" class="%CLASS%" enctype="multipart/form-data" %EXTRA%>
                <div class="form-body">