<div class="flclear clearfix"></div>
<input type="hidden" name="%NAME%" id="%ID%" value="%VALUE%"  %EXTRA% />
