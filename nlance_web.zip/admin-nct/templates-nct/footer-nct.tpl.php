<div class="footer">
  <div class="footer-inner">
    <?php //echo $this->fotoerPanel;?>
    <table border="0" align="center" width="100%" cellpadding="0" cellspacing="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td align="left">Copyright &copy; <?php echo date('Y'); ?>  <?php echo SITE_NM; ?>, All Rights Reserved.<br />
          Thank you for partnering with <a href="http://www.ncrypted.com" target="_blank">NCrypted</a>. <a href="http://www.ncrypted.com/contact" target="_blank">Request Support</a></td>
        <td align="right"><a href="http://www.ncrypted.net/" target="_blank" title="Web Development Company"><img src="<?php echo SITE_ADM_IMG; ?>nct-logo.png" alt="Web Development Company" /></a></td>
      </tr>
    </table>
  </div>
</div>
