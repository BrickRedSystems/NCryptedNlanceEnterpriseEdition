<li><a href="%LINK%">%TITLE%</a></li>

