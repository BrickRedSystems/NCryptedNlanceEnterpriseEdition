<li class="row">
    <a href="%NOTIFICATION_URL%" title="%NOTIFICATION_TITLE%">
        <div class="col1">
            <div class="cont">
                <div class="cont-col2">
                    <div class="desc">
                        %NOTIFICATION%
                    </div>
                </div>
            </div>
        </div>
        <div class="col2">
            <div class="date">
                %TIME_AGO% - %NOTIFICATION_DATE%
            </div>
        </div>
    </a>
</li>
