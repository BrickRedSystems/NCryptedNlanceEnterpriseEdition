<div class="switch-small">
  <input type="checkbox" name="%NAME%" id="%NAME%" class="make-switch %CLASS%" data-action="%ACTION%" %CHECK% data-on-label="<i class='fa fa-check'></i>" data-off-label="<i class='fa fa-times' ></i>" %EXTRA%>
</div>
