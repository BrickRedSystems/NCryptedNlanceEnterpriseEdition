<div class="form-group">
	<label for="page_title" class="control-label col-md-3"><font color="#FF0000">*</font>%label% (%languageName%): &nbsp;</label>
	<div class="col-md-4">
		<input type="text" class="form-control logintextbox-bg required" name="%fieldName%" id="%fieldName%" value="%fieldValue%">
	</div>
</div>