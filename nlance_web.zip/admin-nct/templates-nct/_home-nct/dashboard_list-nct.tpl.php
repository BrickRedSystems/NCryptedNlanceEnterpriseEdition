 <a href="%PAGE_LINK%">
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
  <div class="dashboard-stat %COLOR%">
    <div class="visual"> <i class="fa %IMAGE%" "></i> </div>
    <div class="details"> 
      <div class="desc mar10">%PAGE_TITLE%</div>
    </div>
  </div>
</div>
</a>
