<select id="year_%REPORT_TYPE%" name="year_%REPORT_TYPE%" class="form-control year">
    <option value="-">Select Year</option>
    %YEAR_OPTIONS%
</select>
