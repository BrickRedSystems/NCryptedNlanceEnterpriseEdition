<select id="month_%REPORT_TYPE%" name="month_%REPORT_TYPE%" class="form-control month">
    <option value="-">Select Month</option>
    %MONTH_OPTIONS%
</select>