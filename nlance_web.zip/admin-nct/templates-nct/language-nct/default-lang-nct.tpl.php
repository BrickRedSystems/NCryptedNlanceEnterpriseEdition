<div class="form-group">
	<label class="control-label col-md-3">Default Language: &nbsp;</label>
	<div class="col-md-4">
		<div class="radio-list" data-error-container="#form_2_Default Language: _error">
			<label class="">
			<input class="radioBtn-bg required" id="y" name="isDefault" type="radio" value="y" %DEFAULT_Y%>Yes</label>
			<span for="isDefault" class="help-block"></span>
			<label class="">
			<input class="radioBtn-bg required" id="n" name="isDefault" type="radio" value="n" %DEFAULT_N%>No</label>
			<span for="isDefault" class="help-block"></span>
		</div>
		<div id="form_2_Default Language: _error"></div>
	</div>
</div>