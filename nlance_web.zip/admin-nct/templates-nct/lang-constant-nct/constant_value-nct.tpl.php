		<div class="form-group">
			<label for="constantValue[%ID%]" class="control-label col-md-3"> %MEND_SIGN%
				Constant Value : (%LANGUAGE_NAME%) &nbsp;
			</label>
			<div class="col-md-4">
				<textarea class="form-control logintextbox-bg required" name="constantValue[%ID%]" id="constantValue[%ID%]">%CONSTANT_VALUE%</textarea>
			</div>
		</div>
	