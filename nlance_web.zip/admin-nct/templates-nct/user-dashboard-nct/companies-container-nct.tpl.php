<table border="1" align="left" class="common_table">
    <tbody>
        <tr>
            <th>Company Name</th>
            <th>Industry</th>
            <th>Company Size</th>
            <th>Services Provided</th>
            <th>Website of Company</th>
            <th>Added On</th>
            <th>Updated On</th>
        </tr>
        <?php echo $this->companies; ?>
    </tbody>
</table>
