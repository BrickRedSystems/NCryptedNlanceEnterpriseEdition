<table border="1" align="left" class="common_table">
    <tbody>
        <tr>
            <th>Degree Name</th>
            <th>University Name</th>
            <th>Field of Study</th>
            <th>From</th>
            <th>To</th>
            <th>Grade or Percentage</th>
            <th>Description</th>
        </tr>
        <?php echo $this->educations; ?>
    </tbody>
</table>
