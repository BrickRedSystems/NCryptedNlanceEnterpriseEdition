<table border="1" align="left" class="common_table">
    <tbody>
        <tr>
            <th>Company Name</th>
            <th>Job Category</th>
            <th>Job Title</th>
            <th>Job Position</th>
            <th>Salary Offered Min.</th>
            <th>Salary Offered Max.</th>
            <th>Min. Experience( In years )</th>
            <th>Employment Type</th>
            <th>Last Date of Application</th>
            <th>Posted On</th>
            <th>Posted By</th>
            <th>Applied On</th>
        </tr>
        <?php echo $this->jobs; ?>
    </tbody>
</table>
