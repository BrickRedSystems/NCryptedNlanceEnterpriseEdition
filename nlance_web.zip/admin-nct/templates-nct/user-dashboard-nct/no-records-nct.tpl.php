<tr>
    <td colspan="<?php echo $this->colspan; ?>"><?php echo $this->no_records_message; ?></td>
</tr>