<table border="1" align="left" class="common_table">
    <tbody>
        <tr>
            <th>Group Name</th>
            <th>Group Type</th>
            <th>Website</th>
            <th>Privacy</th>
            <th>Accessibility</th>
            <th>Added On</th>
            <th>Updated On</th>
            <th>Joined On</th>
        </tr>
        <?php echo $this->groups; ?>
    </tbody>
</table>
