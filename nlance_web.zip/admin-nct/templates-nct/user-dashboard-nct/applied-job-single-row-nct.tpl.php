<tr>
    <td>%COMPANY_NAME%</td>
    <td>%JOB_CATEGORY%</td>
    <td>%JOB_TITLE%</td>
    <td>%JOB_POSITION%</td>
    <td>%SALARY_OFFERED_MIN%</td>
    <td>%SALARY_OFFERED_MAX%</td>
    <td>%MIN_EXPERIENCE%</td>
    <td>%EMPLOYMENT_TYPE_TEXT%</td>
    <td>%LAST_DATE_OF_APPLICATION%</td>
    <td>%ADDED_ON%</td>
    <td>%POSTED_BY%</td>
    <td>%APPLIED_ON%</td>
    
</tr>
