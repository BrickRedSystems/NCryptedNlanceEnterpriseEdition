<tr>
    <td>%JOB_TITLE%</td>
    <td>%COMPANY_NAME%</td>
    <td>%JOB_LOCATION%</td>
    <td>%WORKED_FROM%</td>
    <td>%WORKED_TO%</td>
</tr>