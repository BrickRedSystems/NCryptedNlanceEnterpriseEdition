<table border="1" align="left" class="common_table">
    <tbody>
        <tr>
            <th>Job Title</th>
            <th>Company Name</th>
            <th>Job Location</th>
            <th>From</th>
            <th>To</th>
        </tr>
        <?php echo $this->experience; ?>
    </tbody>
</table>