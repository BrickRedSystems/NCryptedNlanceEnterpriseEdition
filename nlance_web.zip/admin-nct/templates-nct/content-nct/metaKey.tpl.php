<div class="form-group">
	<label for="meta_keyword" class="control-label col-md-3">Meta Keyword: &nbsp;</label>
	<div class="col-md-4">
		<textarea class="form-control textarea-bg" name="metaKeyword" id="metaKeyword">%META_KEYWORD%</textarea>
	</div>
</div>