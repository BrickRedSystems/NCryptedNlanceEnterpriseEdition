<div class="form-group">
	<label for="meta_desc" class="control-label col-md-3">Meta Description: &nbsp;</label>
	<div class="col-md-4">
		<textarea class="form-control textarea-bg" name="metaDesc" id="metaDesc">%META_DESCRIPTION%</textarea>
	</div>
</div>
<div class="padtop10 flclear"></div>