<div class="form-group">
	<label for="page_title" class="control-label col-md-3"><font color="#FF0000">*</font>Page Title (%languageName%): &nbsp;</label>
	<div class="col-md-4">
		<input type="text" class="form-control logintextbox-bg required" name="pageTitle[%id%]" id="pageTitle[%id%]" value="%PAGE_TITLE%">
	</div>
</div>