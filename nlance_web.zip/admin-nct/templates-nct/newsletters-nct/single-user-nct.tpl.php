<label class=""> 
    <input type="checkbox" class="required" id="user_%USER_ID%" name="users[]" value="%USER_ID%" %CHECKED% /> %USER_NAME%
</label>