<div class="form-group"> 
	<label for="newsletter_subject" class="control-label col-md-3">%MEND_SIGN%Newsletter Subject (%languageName%): &nbsp;</label>
	<div class="col-md-4"> 
	<input type="text" class="form-control logintextbox-bg required" name="newsletter_subject[%id%]" id="newsletter_subject[%id%]" value="%NLSUBJECT%" />
	</div>
</div>