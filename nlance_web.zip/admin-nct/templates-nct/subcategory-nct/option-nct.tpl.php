

			<option value="%VALUE%" %SELECTED% >%LABEL%</option>
		