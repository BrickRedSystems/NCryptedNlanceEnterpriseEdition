<div class="form-group"> 
	 		<label for="plan_price" class="control-label col-md-3">%label% (%languageName%): &nbsp;</label> 
	 		<div class="col-md-4"> 
	 			<textarea class="form-control required" name="%fieldName%" id="%fieldName%" >%fieldValue%</textarea>
	 		</div>
	 	</div>