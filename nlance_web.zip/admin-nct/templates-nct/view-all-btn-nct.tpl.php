<a title="View all records" class="btn blue" href="<?php echo $this->module_url; ?>">
    <i class="fa fa-upload"></i> View all records 
</a>
