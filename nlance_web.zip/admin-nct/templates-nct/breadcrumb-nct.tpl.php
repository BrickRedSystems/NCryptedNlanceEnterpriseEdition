<ul class="page-breadcrumb breadcrumb">
  <li> <i class="fa fa-home"></i> <a href="<?php echo SITE_ADMIN_URL; ?>modules-nct/home-nct/"> Home </a> <i class="fa fa-angle-right"></i></li>
  <?php echo $this->breadcrumb_list; ?>
  <li class="pull-right">
    <div id="dashboard-report-range" class="dashboard-date-range tooltips" data-placement="top" data-original-title="Change dashboard date range"> <i class="fa fa-calendar"></i> <span> </span> <i class="fa fa-angle-down"></i> </div>
  </li>
</ul>
