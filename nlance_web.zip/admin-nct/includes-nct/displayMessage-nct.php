<?php
	require_once("../../includes-nct/config-nct.php");
	echo disMessage($toastr_message);
?>